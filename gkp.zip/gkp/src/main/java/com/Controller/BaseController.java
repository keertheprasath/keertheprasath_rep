package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BaseController {
	@RequestMapping("/")
	public String gofi(){
		System.out.println("In Controller");
		return "fi";
	}

}
