package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class profilecontroller{
	@RequestMapping("/")
	public String goUserprofile(){
		System.out.println("In Controller");
		return "Userprofile";
	
	}
	@RequestMapping("/login")
	public String gologin(){
		System.out.println("In Login");
		return "login";
		
	}
	@RequestMapping("/signup")
	public String gosignup(){
		System.out.println("In Signup");
		return "signup";
		
	}
}
