package Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BaseController {

	@RequestMapping("/")
	public String goHome(){
		return "index";
	}
	@RequestMapping("/Login")
	public String goLogin(){
		return "Login";
		
	}
	@RequestMapping("/Register")
	public String goRegister(){
		return "Register";
	}
	
	}
