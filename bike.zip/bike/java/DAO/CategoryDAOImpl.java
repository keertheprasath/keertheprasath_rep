package DAO;

import java.util.List;

import Model.CategoryModel;

public class CategoryDAOImpl implements CategoryDAO {

	@Override
	public void addCategory(CategoryModel p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void viewCategory(String code) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteCategory(CategoryModel p) {
		// TODO Auto-generated method stub

	}

	@Override
	public void editCategory(CategoryModel p) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<CategoryModel> ViewCategoryModel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CategoryModel viewCategoryby(String code) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
