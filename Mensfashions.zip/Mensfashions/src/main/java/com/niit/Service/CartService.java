package com.niit.Service;

import com.niit.Model.Cart;

public interface CartService {

    Cart getCartById (int cartId);

    void update(Cart cart);
}
