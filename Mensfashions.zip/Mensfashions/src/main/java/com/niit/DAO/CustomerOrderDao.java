package com.niit.DAO;

import com.niit.Model.CustomerOrder;

public interface CustomerOrderDao {

    void addCustomerOrder(CustomerOrder customerOrder);

}
