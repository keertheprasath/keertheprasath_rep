package com.DAO;

import java.util.List;

import com.Model.SupplierModel;

public interface SupplierDAO { 
	void addSupplier(SupplierModel p);
    void viewSupplier(String code );
    void deleteSupplier(SupplierModel p);
    void editSupplier(SupplierModel p);
    List<SupplierModel>ViewSupplierModel();
    SupplierModel viewSupplierby(String code);
}

