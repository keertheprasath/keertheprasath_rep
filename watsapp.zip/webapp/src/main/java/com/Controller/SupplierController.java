package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SupplierController {
	@RequestMapping("/supplier")
	public String gosupplier(){
		return "supplier";
	}
	
	@RequestMapping("/viewsupplier")
	public String goviewsupplier(){
		return "viewsupplier";
	}
	
	@RequestMapping("/editsupplier")
	public String goeditsupplier(){
		return "editsupplier";
	}
	@RequestMapping("/deletesupplier")
	public String godeletesupplier(){
		return "deletesupplier";
	}
}

