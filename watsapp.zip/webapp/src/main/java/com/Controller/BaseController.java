package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BaseController {

	@RequestMapping("/")
	public String goHome(){
		System.out.println("In Controller");
		return "index";
	}
	@RequestMapping("/Login")
	public String goLogin(){
		System.out.println("In Login");
		return "Login";
	}
		@RequestMapping("/Register")
		public String goRegister(){
			System.out.println("In Register");
			return "Register";
	}
	@RequestMapping("/Services")
	public String goServices(){
		return "Services";
	}
	@RequestMapping("/Warranty")
	public String goWarranty(){
		return "Warranty";
	}
	
	@RequestMapping("/sidebar")
	public String gosidebar(){
		return "sidebar";
	
}}
