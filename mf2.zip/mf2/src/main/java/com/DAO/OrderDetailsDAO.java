package com.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Model.OrderDetails;

@Repository
public class OrderDetailsDAO {
	@Autowired
	SessionFactory SF;
void addOrderDetails (OrderDetails od){
	Session s=SF.openSession();
	Transaction t= s.beginTransaction();
	s.saveOrUpdate(od);
	t.commit();
		
}
	List <OrderDetails> viewOrderDetails(){
		Session s=SF.openSession();
		Transaction t= s.beginTransaction();
		List <OrderDetails> l=(List <OrderDetails>)s.createCriteria(OrderDetails.class).list();
		t.commit();
		return l;
}
  OrderDetails ViewOrderDetailsbyEmail(String email){
	  Session s=SF.openSession();
		Transaction t= s.beginTransaction();
		Query q=s.createQuery("from OrderDetails where email=;email");
		q.setParameter("email",email);
		
     return (OrderDetails)q.uniqueResult();
  }
}


