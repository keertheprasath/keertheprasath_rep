package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BaseController {

	@RequestMapping("/")
	public String goMenu(){
		System.out.println("In Controller");
		return "home";
	}
	
	@RequestMapping("/contact")
	public String gocontact(){
		System.out.println("In Controller");
		return "contact";
	}
	@RequestMapping("/Login")
	public String goLogin(){
		System.out.println("In Login");
		return "Login";
		
	}
	
	@RequestMapping("/Support")
	public String goSupport(){
		System.out.println("In Support");
		return "Support";
	}
	
	
	@RequestMapping("/shop")
	public String goshop(){
		System.out.println("In shop");
		return "shop";
	}
	
	@RequestMapping("/cart")
	public String gocart(){
		System.out.println("In cart");
		return "cart";
	}
	
	
	
	@RequestMapping("/singleproduct")
	public String gosingleproduct(){
		System.out.println("singleproduct");
		return "singleproduct";
	}
	@RequestMapping("/userhome")
	public String goUserhome(){
		System.out.println("In Controller");
		return "userhome";
	}
	@RequestMapping("/adminhome")
	public String goadminhome(){
		System.out.println("In Controller");
		return "adminhome";
	}
}
