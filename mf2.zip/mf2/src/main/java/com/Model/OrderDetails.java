package com.Model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;



@Entity
public class OrderDetails {
	
    @Id
    @Column
    @NotEmpty(message="Type your Code")
    private String code;
    @Column
    @NotEmpty(message="Type your firstname")
    private String firstname;
    @Column
    @NotEmpty(message="Type your lastname")
    private String lastname;

    @Column
    @NotEmpty(message="Type your email")
    private String email;
    @Column
    @NotEmpty(message="Type your Purchase")
    private String purchase;
    @Transient
    private MultipartFile file;
    
    
    public String getusercode() {
        return code;
    }

    public void setcode(String code) {
        this.code = code;
    }

    public String getfirstname() {
        return firstname;
    }

    public void setfirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getlastname() {
        return lastname;
    }

    public void setlastname(String lastname) {
        this.lastname = lastname;
    }

    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }
    public String getpurchase() {
        return purchase;
    }

    public void setpurchase(String purchase) {
        this.purchase = purchase;
    }
	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
    
}
    