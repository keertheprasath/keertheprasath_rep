package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.BlogDAO;
import com.DAO.UserDAO;
import com.Model.BlogModel;
import com.Model.CustModel;

@Controller
public class BaseController {
	@Autowired
	UserDAO ud;
	@Autowired
	BlogDAO bd;
	
	@ModelAttribute("obj")
	public CustModel getOb(){
		return new CustModel();
	}
	@RequestMapping("/save")
	public ModelAndView goInd4(@ModelAttribute("obj")CustModel x){
		ModelAndView m = new ModelAndView("ui");
		ud.addcust(x);
		return m;
	}
	
	@RequestMapping("/view")
	public ModelAndView goInd2(){
		ModelAndView m = new ModelAndView("profile");
		m.addObject("data",ud.viewCust());
	return m;
	}
	
	@RequestMapping("/")
	public String goui(){
		System.out.println("In Controller");
		return "ui";
	}
	
	@RequestMapping("/home")
	public String gohome(){
		System.out.println("In Controller");
		return "home";
	}
	@RequestMapping("/editprofile")
	public String goeditprofile(){
		System.out.println("In Controller");
		return "editprofile";
	}
	@RequestMapping("/blog")
	public String goblog(){
		System.out.println("In Controller");
		return "blog";
	}
	
	@RequestMapping("/log")
	public String golog(){
		System.out.println("In Controller");
		return "log";
	}
	@RequestMapping("/404")
	public String go404(){
		System.out.println("In Controller");
		return "404";
	}
	@RequestMapping("/about")
	public String goabout(){
		System.out.println("In Controller");
		return "about";
	}
	
	@RequestMapping("/userprofile")
	public String gouserprofile(){
		System.out.println("In Controller");
		return "userprofile";
	}
	
	@RequestMapping("/logout")
	public String gologout(){
		System.out.println("In Controller");
		return "logout";
	}
	
	@RequestMapping("/CreateBlog")
	public String goCreateBlog(){
		System.out.println("In Controller");
		return "CreateBlog";
	}
	@ModelAttribute("bol")
	public BlogModel getbol(){
		return new BlogModel();
	}
	
	
	@RequestMapping("/saveblog")
	public ModelAndView goInd(@ModelAttribute("bol")BlogModel y){
		ModelAndView m = new ModelAndView("log");
		bd.addBlogModel(y);
		return m;
	}
	
	@RequestMapping("/kk")
	public String gokk(){
		System.out.println("In Controller");
		return "kk";
	}
	
	@RequestMapping("/forum")
	public String goforum(){
		System.out.println("In Controller");
		return "forum";
	}
	
	
	
}





