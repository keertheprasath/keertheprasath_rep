package com.DAO;


public interface ForumDAO {
	
	void addForumModel(ForumModel f);
	List<ForumModel> viewForum();
}
