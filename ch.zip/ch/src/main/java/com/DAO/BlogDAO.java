package com.DAO;

import java.util.List;

import com.Model.BlogModel;

public interface BlogDAO {
	
	
	void addBlogModel(BlogModel b);
	List<BlogModel> viewBlog();

}