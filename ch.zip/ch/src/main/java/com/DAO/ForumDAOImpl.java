package com.DAO;

public class ForumDAOImpl {

}
