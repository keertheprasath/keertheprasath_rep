package com.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;





@Entity
public class Customer {
	
	@Column
	@NotEmpty(message="Type your firstname ")
	private String fname;
	
	@Column
	@NotEmpty(message="Type your Lastname ")
	private String lname;
	
	@Id
	@Column
	@NotEmpty(message="Type your email")
	private String email;
	
	@Column
	@NotEmpty(message="Type your pwd")
	private String pwd;

	@Column
	@NotEmpty(message="Type your addr")
	private String addr;
	
	@Column
	private boolean enabled;
	
	@Column
	private String role;

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	
}
