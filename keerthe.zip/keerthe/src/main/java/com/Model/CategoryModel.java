package com.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
public class CategoryModel {
	@Id
	@Column
	@NotEmpty(message="Type your code")
 private String code;
    @Column
    @NotEmpty(message="Type your name")
    private String name;
    
    
   
    public String getcode () {
        return code;
    }

    public void setcode (String code) {
        this.code = code;
    }  
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
       
