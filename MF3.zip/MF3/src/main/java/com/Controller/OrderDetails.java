package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.OrderDetailsDAO;

@Controller 
public class OrderDetails {
@Autowired
OrderDetailsDAO od;

@RequestMapping("/checkout")
public ModelAndView gocheckout(){
	ModelAndView view = new ModelAndView("checkout");
	view.addObject("orderobj",new OrderDetails());
	System.out.println("In checkout");
	return view;
}
}
