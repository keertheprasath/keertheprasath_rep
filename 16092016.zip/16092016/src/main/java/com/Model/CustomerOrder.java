package com.Model;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.Model.CustomerModel;

public class CustomerOrder implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
   @Id
    @GeneratedValue
   
    public int customerOrderId;
    @OneToOne
    @JoinColumn(name="cartId")
    public  Cart cart;
    @OneToOne
    @JoinColumn(name="id")
    public CustomerModel customermodel;
    @OneToOne
    @JoinColumn(name="billingAddressId")
    public BillingAddress billingAddress;
    @OneToOne
    @JoinColumn(name="shippingAddressId")
    public ShippingAddress shippingAddress;
    public int getCustomerOrderId() {
        return customerOrderId;
    }
    public void setCustomerOrderId(int customerOrderId) {
        this.customerOrderId = customerOrderId;
    }
    public Cart getCart() {
        return cart;
    }
    public void setCart(Cart cart) {
        this.cart = cart;
    }
   
    
    public CustomerModel getCustomermodel() {
		return customermodel;
	}
	public void setCustomermodel(CustomerModel customermodel) {
		this.customermodel = customermodel;
	}
	public BillingAddress getBillingAddress() {
        return billingAddress;
    }
    public void setBillingAddress(BillingAddress billingAddress) {
        this.billingAddress = billingAddress;
    }
    public ShippingAddress getShippingAddress() {
        return shippingAddress;
    }
    public void setShippingAddress(ShippingAddress shippingAddress) {
        this.shippingAddress = shippingAddress;
    }
   

}