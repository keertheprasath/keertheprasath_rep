package com.DAO;

import com.Model.CustomerOrder;

public interface CustomerOrderDAO {
void addSupplier(CustomerOrder p);
    
    void deleteCustomer(CustomerOrder p);
    CustomerOrder viewCustomerby(String code);
}
