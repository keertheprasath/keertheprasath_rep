package com.DAO;

import java.util.List;

import com.Model.CustomerModel;

public interface CustomerDAO {
	void addCustomer(CustomerModel c);
	void delCustomer(String emailId);
	void updCustomer(CustomerModel c);
	List<CustomerModel> viewCustomer();
	CustomerModel viewCustomerByEmail(String email);
}
