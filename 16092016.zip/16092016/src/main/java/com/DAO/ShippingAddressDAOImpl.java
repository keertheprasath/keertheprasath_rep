/**
 * 
 */
package com.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.ShippingAddress;

/**
 * @author Admin
 *
 */
@Repository("ShippingAddressDAO")
public class ShippingAddressDAOImpl implements ShippingAddressDAO {

	/* (non-Javadoc)
	 * @see com.DAO.ShippingAddressDAO#addSupplier(com.Model.ShippingAddress)
	 */
	@Autowired
	SessionFactory sf;

	@Transactional
	public void addShipping(ShippingAddress p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(p);
		t.commit();

	}

	/* (non-Javadoc)
	 * @see com.DAO.ShippingAddressDAO#deleteShippingAddress(com.Model.ShippingAddress)
	 */
	@Transactional
	public void deleteShippingAddress(ShippingAddress p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(p);
		t.commit();

	}

	/* (non-Javadoc)
	 * @see com.DAO.ShippingAddressDAO#viewShippingby(java.lang.String)
	 */
	public ShippingAddress viewShippingby(String code) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(code);
		t.commit();
		return null;
	}

}
