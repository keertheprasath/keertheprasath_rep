package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.UserDAO;
import com.Model.CustModel;

@Controller
public class BasesController {
	@Autowired
	UserDAO ud;
	
	@ModelAttribute("obj")
	public CustModel getOb(){
		return new CustModel();
	}
	@RequestMapping("/save")
	public ModelAndView goInd4(@ModelAttribute("obj")CustModel x){
		ModelAndView m = new ModelAndView("ui");
		ud.addcust(x);
		return m;
	}
	
	@RequestMapping("/view")
	public ModelAndView goInd2(){
		ModelAndView m = new ModelAndView("profile");
		m.addObject("data",ud.viewCust());
	return m;
	}
	
	@RequestMapping("/")
	public String goui(){
		System.out.println("In Controller");
		return "ui";
	}
	
	@RequestMapping("/home")
	public String gohome(){
		System.out.println("In Controller");
		return "home";
	}
	@RequestMapping("/editprofile")
	public String goeditprofile(){
		System.out.println("In Controller");
		return "editprofile";
	}
	@RequestMapping("/blog")
	public String goblog(){
		System.out.println("In Controller");
		return "blog";
	}
	@RequestMapping("/createblog")
	public String gocreateblog(){
		System.out.println("In Controller");
		return "createblog";
	}
	@RequestMapping("/log")
	public String golog(){
		System.out.println("In Controller");
		return "log";
	}
	@RequestMapping("/404")
	public String go404(){
		System.out.println("In Controller");
		return "404";
	}
	
	
	
	
	
}





