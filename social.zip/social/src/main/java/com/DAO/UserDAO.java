package com.DAO;

import java.util.List;

import com.Model.CustModel;

public interface UserDAO {
    void addcust(CustModel c);
    List<CustModel>viewCust();
    
    
    
}
