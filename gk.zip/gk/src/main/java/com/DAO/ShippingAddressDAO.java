package com.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Model.ShippingAddress;
import com.Model.ShippingAddress;

@Repository
public class ShippingAddressDAO {
	@Autowired
	SessionFactory SF;
void addShippingAddress (ShippingAddress sa){
	Session s=SF.openSession();
	Transaction t= s.beginTransaction();
	s.saveOrUpdate(sa);
	t.commit();
		
}
	List <ShippingAddress> viewShippingAddress(){
		Session s=SF.openSession();
		Transaction t= s.beginTransaction();
		List <ShippingAddress> l=(List <ShippingAddress>)s.createCriteria(ShippingAddress.class).list();
		t.commit();
		return l;
}
  ShippingAddress ViewShippingAddressbyEmail(String email){
	  Session s=SF.openSession();
		Transaction t= s.beginTransaction();
		Query q=s.createQuery("from ShippingAddress where email=;email");
		q.setParameter("email",email);
		
     return (ShippingAddress)q.uniqueResult();
  }
}


