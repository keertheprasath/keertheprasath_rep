package com.DAO;

import com.Model.ShippingAddress;

public interface ShippingAddressDAO {
void addSupplier(ShippingAddress p);
    
    void deleteShippingAddress(ShippingAddress p);
    ShippingAddress viewShippingby(String code);

}
