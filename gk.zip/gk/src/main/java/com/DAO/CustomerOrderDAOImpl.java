package com.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Model.CustomerOrder;
@Repository
public class CustomerOrderDAOImpl implements CustomerOrderDAO {
	@Autowired
	SessionFactory SF;
void addCustomerOrder (CustomerOrder od){
	Session s=SF.openSession();
	Transaction t= s.beginTransaction();
	s.saveOrUpdate(od);
	t.commit();
		
}


	List <CustomerOrder> viewCustomerOrder(){
		Session s=SF.openSession();
		Transaction t= s.beginTransaction();
		List <CustomerOrder> l=(List <CustomerOrder>)s.createCriteria(CustomerOrder.class).list();
		t.commit();
		return l;
}
  CustomerOrder ViewCustomerOrderbyEmail(String email){
	  Session s=SF.openSession();
		Transaction t= s.beginTransaction();
		Query q=s.createQuery("from CustomerOrderDetails where email=;email");
		q.setParameter("email",email);
		
     return (CustomerOrder)q.uniqueResult();
  }

public void addSupplier(CustomerOrder p) {
	// TODO Auto-generated method stub
	
}
public void deleteCustomer(CustomerOrder p) {
	// TODO Auto-generated method stub
	
}


public CustomerOrder viewCustomerby(String code) {
	// TODO Auto-generated method stub
	return null;
}

}
