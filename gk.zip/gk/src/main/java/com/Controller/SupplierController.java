package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.SupplierDAO;
import com.Model.SupplierModel;
import com.Model.CustomerModel;
import com.Model.SupplierModel;
import com.google.gson.Gson;

@Controller
public class SupplierController {
	
	@Autowired
	SupplierDAO pd;
	
	@RequestMapping("/supplier")
	public String goSupplier(){
		System.out.println("In supplier");
		return "supplierlist";
	}
	
	/*@RequestMapping("/viewSupplier")
	public String goviewSupplier(){
		return "viewSupplier";
	}*/
	
	/*@RequestMapping("/viewsupplier")
	public String doviewSupplier(){
		/*List<SupplierModel> l=pd.ViewSupplierModel();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("Supplierlist");
        modelandview.addObject("json",json);
		//System.out.println(json);
		return modelandview;
		return "redirect:/supplierlist";
	}*/
	@RequestMapping("/createsupplier")
	public String goaddSupplier(){
		System.out.println("In Add Supplier");
		//SupplierModel p = new SupplierModel();
		/*
		p.setcode("4");
		p.setname("p2");
		pd.addSupplier(p);
		*/
		return "addsupplier";
	}
	@RequestMapping("/csupplier")
	public String gocsupplier(){
		System.out.println("In supplier");
		return "csupplier";
	}
	@ModelAttribute("sup")
	public SupplierModel doit(){
		return new SupplierModel();
	}
	
	@RequestMapping(value="/savesupplier", method=RequestMethod.POST)
	public String doSave(@ModelAttribute("sup")SupplierModel p){
		System.out.println("insaveSupplier");
		pd.addSupplier(p);
		return "redirect:/supplierlist";
	}
	@RequestMapping("/supplierlist")
	public ModelAndView goSupplierlist(){
		List<SupplierModel> l=pd.ViewSupplierModel();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("supplierlist");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
	}
	@RequestMapping("/editsupplier")
	public String goeditSupplier(){
		return "editsupplier";
	}
	@RequestMapping("/editsup/{code}")
	public ModelAndView doeditSupplier(@PathVariable String code){
		System.out.println("In Edit Supplier");
		SupplierModel q = pd.viewSupplierby(code);
		System.out.println("Object : "+q);
		ModelAndView modelandview = new ModelAndView("addsupplier");
		modelandview.addObject("sup", q);
		return modelandview;
	}
	
	@RequestMapping("/delsup/{code}")
	public String godeleteSupplier(@PathVariable String code){
		System.out.println("In Delete Supplier");
		SupplierModel q = pd.viewSupplierby(code);
		//p.getcode();
		pd.deleteSupplier(q);
		//System.out.println(p.getcode());
		return "redirect:/supplierlist";
	}
	@RequestMapping("/dodeleteSupplier")
	public String dodeleteSupplier(@ModelAttribute("Supplier")SupplierModel p){
		System.out.println("In Delete Supplier");
		pd.deleteSupplier(p);
		System.out.println("deleted");
		return "supplierlist";
}
}
