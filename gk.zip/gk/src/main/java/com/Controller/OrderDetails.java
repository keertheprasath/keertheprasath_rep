package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.OrderDetailsDAO;
import com.Model.ShippingAddress;

@Controller 
public class OrderDetails {
@Autowired
OrderDetailsDAO od;
@ModelAttribute("Orderobj")
public OrderDetails getorder(){
return new OrderDetails();
}	
@ModelAttribute("ShippingAdressobj")
public ShippingAddress getShippingAddress(){
return new ShippingAddress();
	
	
	
}

@RequestMapping("/checkout")
public ModelAndView gocheckout(){
	ModelAndView view = new ModelAndView("checkout");
	
	System.out.println("In checkout");
	return view;
}



}
