package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.DAO.ProductDAO;
import com.Model.ProductModel;

@Controller
public class ProductController {
	
	@Autowired
	ProductDAO pd;
	
	@RequestMapping("/product")
	public String goproduct(){
		System.out.println("In Product");
		return "product";
	}
	
	@RequestMapping("/viewproduct")
	public String goviewproduct(){
		return "viewproduct";
	}
	
	@RequestMapping("/addproduct")
	public String goaddproduct(){
		System.out.println("In Add Product");
		ProductModel p = new ProductModel();
		/*p.setcode("4");
		p.setLname("p2");
		p.setprice("12345");
		pd.addProduct(p);
		*/return "addproduct";
	}
	
	@ModelAttribute("product")
	public ProductModel doit(){
		return new ProductModel();
	}
	
	@RequestMapping(value="/saveproduct", method=RequestMethod.POST)
	public String doSave(@ModelAttribute("product")ProductModel p){
		pd.addProduct(p);
		return "a";
	}
	@RequestMapping("/productlist")
	public String goproductlist(){
		return "productlist";
	}
	@RequestMapping("/editproduct")
	public String goeditproduct(){
		return "editproduct";
	}
	@RequestMapping("/deleteproduct")
	public String godeleteproduct(){
		System.out.println("In Delete Product");
		ProductModel q = new ProductModel();
		q.getcode();
		System.out.println(q.getcode());
		return "deleteproduct";
	}
}
