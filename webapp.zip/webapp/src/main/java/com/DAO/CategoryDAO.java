package com.DAO;

import java.util.List;

import com.Model.CategoryModel;

public interface CategoryDAO { 
	void addCategory(CategoryModel p);
    void viewCategory(String code );
    void deleteCategory(CategoryModel p);
    void editCategory(CategoryModel p);
    List<CategoryModel>ViewCategoryModel();
    CategoryModel viewCategoryby(String code);
}



