/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.CategoryModel;

/**
 * @author keertheprasath.G
 *
 */
@Repository
@Transactional
public class CategoryDAOImpl implements CategoryDAO {

	/* (non-Javadoc)
	 * @see DAO.CategoryDAO#addCategory(Model.CategoryModel)
	 */
	@Autowired
	SessionFactory sf;
	
	@Override
	public void addCategory(CategoryModel p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(p);
		t.commit();
	}

	/* (non-Javadoc)
	 * @see DAO.CategoryDAO#viewCategory(java.lang.String)
	 */
	@Override
	public void viewCategory(String code) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see DAO.CategoryDAO#deleteCategory(Model.CategoryModel)
	 */
	@Override
	public void deleteCategory(CategoryModel p) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.delete(p);
		t.commit();

	}

	/* (non-Javadoc)
	 * @see DAO.categoryDAO#editcategory(Model.categoryModel)
	 */
	@Override
	public void editCategory(CategoryModel p) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see DAO.categoryDAO#ViewcategoryModel()
	 */
	@Override
	public List<CategoryModel> ViewCategoryModel() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see DAO.categoryDAO#viewcategoryby(java.lang.String)
	 */
	@Override
	public CategoryModel viewCategoryby(String code) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
