package com.DAO;

import java.util.List;

import org.hibernate.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Model.Customer;

//@Repository("CustomerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	SessionFactory sf;
	
	//@Transactional
	@Override
	public void addCustomer(Customer c) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.save(c);
		t.commit();
		
	}

	@Override
	public void delCustomer(String emailId) {
		// TODO Auto-generated method stub
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		s.delete(emailId);
		t.commit();
	}

	@Override
	public void updCustomer(Customer c) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Customer> viewCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer viewCustomerByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

}
