/**
 * 
 */
package com.DAO;

import java.util.List;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.Model.SupplierModel;


@Repository
@Transactional
public class SupplierDAOImpl implements SupplierDAO {

	/* (non-Javadoc)
	 * @see DAO.SupplierDAO#addSupplier(Model.SupplierModel)
	 */
	@Autowired
	SessionFactory sf;

	@Transactional(propagation=Propagation.REQUIRED)
	public void addSupplier(SupplierModel p) {
		// TODO Auto-generated method stub
				Session s = sf.openSession();
				Transaction t = s.beginTransaction();
				s.saveOrUpdate(p);
				t.commit();
				//s.close();
			}
	
	

	@Transactional(propagation=Propagation.REQUIRED)
	public void deleteSupplier(SupplierModel p) {
		// TODO Auto-generated method stub
		
		Session s=sf.getCurrentSession();
		Transaction t = s.beginTransaction();
		SupplierModel q = new SupplierModel();
		q.setcode(p.getcode());
		q.setName(p.getName());
		s.delete(q);
		t.commit();
		//s.close();
	}

	

	@Transactional(propagation=Propagation.REQUIRED)
	public List<SupplierModel> ViewSupplierModel() {
		// TODO Auto-generated method stub
		
		 Session s = sf.openSession();
		 Transaction t = s.beginTransaction();
		 List<SupplierModel> l = s.createCriteria(SupplierModel.class).list();
		t.commit();
		s.close();
		return l;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public SupplierModel viewSupplierby(String code) {
		// TODO Auto-generated method stub
		/*if(sf.getCurrentSession()!=null)
		{
			s=sf.getCurrentSession();
		}
		else*/
		System.out.println("In Edit Supplier IMpl");
		Session s = sf.openSession();
		 Transaction t = s.beginTransaction();
		 SupplierModel p = (SupplierModel)s.load(SupplierModel.class, code);
		 t.commit();
		 //s.close();
		return p;
	}
	

}