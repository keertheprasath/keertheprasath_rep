/**
 * 
 */


package com.DAO;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Model.CustModel;

@Repository
public class UserDAOImpl implements UserDAO {
	@Autowired
	SessionFactory sf;
		Session s;
		Transaction t;
	
		@Transactional
	
	public void addcust(CustModel c) {
		
			Session s= sf.openSession();
			Transaction t= s.beginTransaction();
			c.setEnabled(true);
			c.setRole("ROLE_USER");
			s.saveOrUpdate(c);
			t.commit();
		}
		// TODO Auto-generated method stub
		
	
		@Transactional
	
	public List<CustModel> viewCust() {
		List<CustModel> l;
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		l = (List<CustModel>)s.createCriteria(CustModel.class).list();
		return l;
		// TODO Auto-generated method stub
		
	}
	
	
		
		
		
		
	}
	
