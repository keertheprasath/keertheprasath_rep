package com.DAO;

import java.util.List;

import com.Model.forumModel;



public interface forumDAO {
	
	void addforumModel(forumModel f);
	List<forumModel> viewforum();
}
