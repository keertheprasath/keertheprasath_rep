package com.Controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.DAO.ProductDAO;
import com.Model.Customer;
import com.Model.ProductModel;
import com.google.gson.Gson;

@Controller
public class ProductController {
	
	ModelAndView m;
	
	@Autowired
	ProductDAO pd;
	
	
	@RequestMapping("/product")
	public String goproduct(){
		System.out.println("In Product");
		return "product";
	}
	
	/*@RequestMapping("/viewproduct")
	public String goviewproduct(){
		return "viewproduct";
	}*/
	
	@RequestMapping("/viewproduct")
	public String doviewproduct(){
		/*List<ProductModel> l=pd.ViewProductModel();
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("productlist");
        modelandview.addObject("json",json);
		//System.out.println(json);
		return modelandview;*/
		return "viewproduct";
	}
	
	@RequestMapping("/addproduct")
	public ModelAndView goaddproduct(){
		
		System.out.println("In Add Product");
		//ProductModel p = new ProductModel();
		/*
		p.setcode("4");
		p.setLname("p2");
		p.setprice("12345");
		
		pd.addProduct(p);
		*/
		m = new ModelAndView("addproduct");
		m.addObject("product", new ProductModel());
		//return "addproduct";
		return m;
	}
	
	/*@ModelAttribute("product")
	public ProductModel doit(){
		return new ProductModel();
	}*/
	
	@RequestMapping(value="/saveproduct", method=RequestMethod.POST)
	public ModelAndView doSave(@Valid @ModelAttribute("product")ProductModel p, BindingResult br){
		m= new ModelAndView("redirect:/productlist");
		if(br.hasErrors()){
			m= new ModelAndView("addproduct");
			m.addObject("product", p);
			return m;
		}
		if (!p.getFile().isEmpty()) {
	            try {
	                byte[] bytes = p.getFile().getBytes();
	 
	                // Creating the directory to store file
	                //String rootPath = System.getProperty("catalina.home");
	                File dir = new File("C:\\Users\\Admin\\Desktop\\myworkspace\\MF\\src\\main\\webapp\\resources\\assets" + File.separator + "tmpFiles");
	                if (!dir.exists())
	                    dir.mkdirs();
	 
	                // Create the file on server
	                File serverFile = new File(dir.getAbsolutePath()
	                        + File.separator + p.getcode());
	                BufferedOutputStream stream = new BufferedOutputStream(
	                        new FileOutputStream(serverFile));
	                stream.write(bytes);
	                stream.close();            
	                System.out.println("You successfully uploaded file=" +"C:\\Users\\Admin\\Desktop\\myworkspace\\MF\\src\\main\\webapp\\resources\\assets"+p.getcode());
	                m.setViewName("home");
	                
	            } catch (Exception e) {
	                System.out.println("You failed to upload " + p.getcode() + " => " + e.getMessage());
	            }
	        } 
			else {
				m.setViewName("addproduct");
	            System.out.println("You failed to upload " + p.getcode() + " because the file was empty.");
	           
	        }
		
		
		System.out.println("insaveproduct");
		pd.addProduct(p);
		return m;
	}
	@RequestMapping("/productlist")
	public ModelAndView goproductlist(HttpServletRequest req){
		List<ProductModel> l=pd.ViewProductModel();
		List<String> z=new ArrayList();
		String rootPath = req.getSession().getServletContext().getRealPath("/");
		for(ProductModel x:l){
			z.add("C:\\Users\\Admin\\Desktop\\myworkspace\\MF\\src\\main\\webapp\\resources\\assets"+"/tmpFiles/"+x.getcode()+".jpg");
		}
		Gson gson = new Gson();
        String json = gson.toJson(l);
        ModelAndView modelandview = new ModelAndView("productlist");
        modelandview.addObject("json",json);
        modelandview.addObject("images",z);
		//System.out.println(json);
		return modelandview;
		}
	
	@RequestMapping("/editproduct")
	public String goeditproduct(){
		return "editproduct";
	}
	@RequestMapping("/editPrd/{code}")
	public ModelAndView doeditproduct(@PathVariable String code){
		ProductModel q = pd.viewProductby(code);
		//System.out.println("Object : "+q);
		ModelAndView modelandview = new ModelAndView("addproduct");
		modelandview.addObject("product", q);
		return modelandview;
	}
	
	@RequestMapping("/delPrd/{code}")
	public String godeleteproduct(@PathVariable String code){
		System.out.println("In Delete Product");
		ProductModel q = pd.viewProductby(code);
		//p.getcode();
		pd.deleteProduct(q);
		//System.out.println(p.getcode());
		return "redirect:/productlist";
	}
	@RequestMapping("/dodeleteproduct")
	public String dodeleteproduct(@ModelAttribute("product")ProductModel p){
		System.out.println("In Delete Product");
		//ProductModel q = new ProductModel();
		p.getcode();
		pd.deleteProduct(p);
		System.out.println(p.getcode());
		return "productlist";
}

	@RequestMapping("/cproduct")
	public ModelAndView gocproduct(){
		List<ProductModel> l=pd.ViewProductModel();
		
		ModelAndView modelandview = new ModelAndView("cproduct");
        modelandview.addObject("json",l);
		//System.out.println(json);
		return modelandview;
	}}
