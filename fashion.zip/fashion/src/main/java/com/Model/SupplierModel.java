package com.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
public class SupplierModel {
	@Id
	@Column
	@NotEmpty(message="Type your code")
    private String code;
    @Column
    @NotEmpty(message="Type your name")
    private String name;
    @Column
    @NotEmpty(message="Type your category")
    private String category;
    
    public String getcode () {
        return code;
    }

    public void setcode (String code) {
        this.code = code;
    }  
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    public String getCategory() {
        return category;
    }

}
       
